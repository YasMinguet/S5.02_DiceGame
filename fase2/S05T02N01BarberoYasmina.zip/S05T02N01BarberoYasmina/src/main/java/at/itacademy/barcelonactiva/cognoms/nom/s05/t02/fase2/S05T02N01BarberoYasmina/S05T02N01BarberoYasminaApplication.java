package at.itacademy.barcelonactiva.cognoms.nom.s05.t02.fase2.S05T02N01BarberoYasmina;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class S05T02N01BarberoYasminaApplication {

	public static void main(String[] args) {
		SpringApplication.run(S05T02N01BarberoYasminaApplication.class, args);
	}

}
